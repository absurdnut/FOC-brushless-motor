 /********************���ݳ�**************************
*****************0.96��  8PIN SPI  TFT FOR STM8S*************
*****STM8S003F3����**************************
***** PC3----3  SCK   ,  PC4----4  SDA   ,PC5---5  RST   PC6----6 DC  PC7---7 CS   
***** BY:GU 
*********GC9106

�������ң���������    160*80  16bit 5 6 5 RGB ģʽ  ��λ��ǰ �����ң����ϵ���
********************************************************/
#include "IOSTM8S003F3.h"

#define set_0   0x01
#define set_1   0x02
#define set_2   0x04
#define set_3   0x08    
#define set_4   0x10
#define set_5   0x20
#define set_6   0x40
#define set_7   0x80

#define clr_0   0xFE
#define clr_1   0xFD
#define clr_2   0xFB
#define clr_3   0xF7    
#define clr_4   0xEF
#define clr_5   0xDF
#define clr_6   0xBF
#define clr_7   0x7F
/**********SPI���ŷ��䣬����TFT��������ʵ������޸�*********/

#define SPI_SCK_0  PC_ODR&=clr_3        //PC3       
#define SPI_SCK_1  PC_ODR|=set_3       
#define SPI_SDA_0  PC_ODR&=clr_4        //PC4        
#define SPI_SDA_1  PC_ODR|=set_4
#define SPI_RST_0  PC_ODR&=clr_5        //PC5        
#define SPI_RST_1  PC_ODR|=set_5
#define SPI_DC_0  PC_ODR&=clr_6           //PC6
#define SPI_DC_1  PC_ODR|=set_6
#define SPI_CS_0  PC_ODR&=clr_7          //PC7
#define SPI_CS_1  PC_ODR|=set_7


//������ʾ�����С��ƫ��
#define TFT_COLUMN_NUMBER 160
#define TFT_LINE_NUMBER 80
#define TFT_COLUMN_OFFSET 0
#define TFT_LINE_OFFSET 24

//���峣����ɫ
#define RED   0XF800
#define GREEN   0X07E0
#define BLUE  0X001F
#define PIC_LEN 120
#define PIC_HIG 80
#define PIC_NUMBER 28800

const unsigned char  *point;


const unsigned char china_char[][32]=   		//
{
{0x00,0x00,0xE4,0x3F,0x28,0x20,0x28,0x25,0x81,0x08,0x42,0x10,0x02,0x02,0x08,0x02,
0xE8,0x3F,0x04,0x02,0x07,0x07,0x84,0x0A,0x44,0x12,0x34,0x62,0x04,0x02,0x00,0x02},/*"��",0*/
{0x88,0x20,0x88,0x24,0x88,0x24,0x88,0x24,0x88,0x24,0xBF,0x24,0x88,0x24,0x88,0x24,
0x88,0x24,0x88,0x24,0x88,0x24,0xB8,0x24,0x87,0x24,0x42,0x24,0x40,0x20,0x20,0x20},/*"��",1*/
{0x80,0x00,0x80,0x00,0x40,0x01,0x20,0x02,0x10,0x04,0x08,0x08,0xF4,0x17,0x83,0x60,
0x80,0x00,0xFC,0x1F,0x80,0x00,0x88,0x08,0x90,0x08,0x90,0x04,0xFF,0x7F,0x00,0x00},/*"��",2*/
{0x80,0x00,0x82,0x00,0x84,0x0F,0x44,0x08,0x20,0x04,0xF0,0x3F,0x27,0x22,0x24,0x22,
0xE4,0x3F,0x04,0x05,0x84,0x0C,0x84,0x54,0x44,0x44,0x24,0x78,0x0A,0x00,0xF1,0x7F},/*"��",3*/
{0xF8,0x0F,0x08,0x08,0xF8,0x0F,0x08,0x08,0xF8,0x0F,0x00,0x00,0xFC,0x3F,0x04,0x00,
0xF4,0x1F,0x04,0x00,0xFC,0x7F,0x94,0x10,0x14,0x09,0x12,0x06,0x52,0x18,0x31,0x60},/*"��",4*/
{0x80,0x00,0x80,0x00,0x80,0x00,0xFC,0x1F,0x84,0x10,0x84,0x10,0x84,0x10,0xFC,0x1F,
0x84,0x10,0x84,0x10,0x84,0x10,0xFC,0x1F,0x84,0x50,0x80,0x40,0x80,0x40,0x00,0x7F},/*"��",5*/
{0x00,0x00,0xFE,0x1F,0x00,0x08,0x00,0x04,0x00,0x02,0x80,0x01,0x80,0x00,0xFF,0x7F,
0x80,0x00,0x80,0x00,0x80,0x00,0x80,0x00,0x80,0x00,0x80,0x00,0xA0,0x00,0x40,0x00},/*"��",6*/
{0x00,0x00,0xE4,0x1F,0x48,0x10,0x48,0x10,0x41,0x10,0x82,0x08,0x92,0x08,0x90,0x08,
0x08,0x05,0x08,0x05,0x07,0x02,0x04,0x02,0x04,0x05,0x84,0x08,0x44,0x10,0x30,0x60},/*"��",7*/
{0x40,0x00,0x80,0x00,0xFE,0x7F,0x02,0x40,0x01,0x20,0xF8,0x07,0x00,0x02,0x00,0x01,
0x80,0x00,0xFF,0x7F,0x80,0x00,0x80,0x00,0x80,0x00,0x80,0x00,0xA0,0x00,0x40,0x00},/*"��",8*/
{0x00,0x01,0x04,0x02,0xE8,0x3F,0x28,0x20,0x01,0x00,0xC2,0x1F,0x02,0x02,0xC8,0x1F,
0x48,0x12,0xC4,0x1F,0x47,0x12,0xC4,0x1F,0x04,0x00,0x84,0x08,0x44,0x10,0x20,0x20},/*"��",9*/
{0x00,0x00,0xFC,0x1F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,0x7F,0x80,0x00,
0x80,0x00,0x88,0x08,0x88,0x10,0x84,0x20,0x82,0x40,0x81,0x40,0xA0,0x00,0x40,0x00},/*"ʾ",10*/


};

void delay_us(unsigned int _us_time)
{       
  unsigned char x=0;
  for(;_us_time>0;_us_time--)
  {
    x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
	  x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;x++;
  }
}
void delay_ms(unsigned int ms_time)
  {
    unsigned int i,j;
    for(i=0;i<ms_time;i++)
    {
    for(j=0;j<900;j++)
      {;}
    }
  }
/*************SPI���ú���*******************
SCL����ʱ�͵�ƽ����һ�������ز���
ģ��SPI
******************************************/

/**************************SPIģ�鷢�ͺ���************************************************

 *************************************************************************/
void SPI_SendByte(unsigned char byte)
{
  
  unsigned char counter;
   
  for(counter=0;counter<8;counter++)
  { 
    SPI_SCK_0;
	  
    if((byte&0x80)==0)
    {
      SPI_SDA_0;
    }
    else SPI_SDA_1;
    byte=byte<<1;
	
    SPI_SCK_1;	
	
	SPI_SCK_0;
		
  } 
}

void TFT_SEND_CMD(unsigned char o_command)
  {
    SPI_DC_0;
    SPI_CS_0;
    SPI_SendByte(o_command);
    SPI_CS_1;
	 
    //SPI_DC_1;
  }
void TFT_SEND_DATA(unsigned char o_data)
  { 
    SPI_DC_1;
    SPI_CS_0;
    SPI_SendByte(o_data);
    SPI_CS_1;
	  
   }
  void  TFT_ADR_SET(void)
  {
	    TFT_SEND_CMD(0x2a);     //Column address set
  TFT_SEND_DATA(0x00);    //start column
  TFT_SEND_DATA(0x00+TFT_COLUMN_OFFSET); 
  TFT_SEND_DATA(0x00);    //end column
  TFT_SEND_DATA(TFT_COLUMN_NUMBER -1+ TFT_COLUMN_OFFSET);

  TFT_SEND_CMD(0x2b);     //Row address set
  TFT_SEND_DATA(0x00);    //start row
  TFT_SEND_DATA(0x00+TFT_LINE_OFFSET); 
  TFT_SEND_DATA(0x00);    //end row
  TFT_SEND_DATA(TFT_LINE_NUMBER-1+ TFT_LINE_OFFSET);
    TFT_SEND_CMD(0x2C);     //Memory write
  }
void TFT_clear(void)
  {
    unsigned int ROW,column;
	TFT_ADR_SET();
    for(ROW=0;ROW<TFT_LINE_NUMBER;ROW++)             //ROW loop
      { 
    
          for(column=0;column<TFT_COLUMN_NUMBER;column++)  //column loop
            {
              TFT_SEND_DATA(0x00);
        TFT_SEND_DATA(0x00);
        TFT_SEND_DATA(0x00);
            }
      }
  }
void TFT_full(unsigned long color)
  {
    unsigned int ROW,column;
    TFT_ADR_SET();
    for(ROW=0;ROW<TFT_LINE_NUMBER;ROW++)             //ROW loop
      { 
    
  for(column=0;column<TFT_COLUMN_NUMBER ;column++) //column loop
          {
        
        TFT_SEND_DATA(color>>8);
        TFT_SEND_DATA(color);
          }
      }
  }
void TFT_init(void)        ////GC9106
  {
  SPI_SCK_0;
  SPI_RST_0; 
  delay_ms(1000);
  SPI_RST_1;
  delay_ms(1000);				//RESET 
    TFT_SEND_CMD(0xfe);     //Inter register enable 1
    TFT_SEND_CMD(0xfe);     
    TFT_SEND_CMD(0xfe);
    TFT_SEND_CMD(0xef);     //Inter register enable 2

    TFT_SEND_CMD(0xb3);     //����٤����������
    TFT_SEND_DATA(0x03);
        
    TFT_SEND_CMD(0x36);     //Memory Access Ctrl
    TFT_SEND_DATA(0x68);        //MY MX MV ML BGR MH 0 0  ����D8 
        
    TFT_SEND_CMD(0x3a);             //Pixel Format Set
    TFT_SEND_DATA(0x05);            //16BIT  565��ʽ

    TFT_SEND_CMD(0xb6);           //��������
    TFT_SEND_DATA(0x11);
    TFT_SEND_CMD(0xac);  
    TFT_SEND_DATA(0x0b);

    TFT_SEND_CMD(0xb4);             //Display Inversion Control
    TFT_SEND_DATA(0x21);

    TFT_SEND_CMD(0xb1);             //��������
    TFT_SEND_DATA(0xc0);

    TFT_SEND_CMD(0xe6);              //VREG1_CTL   
    TFT_SEND_DATA(0x50);
    TFT_SEND_DATA(0x43);	        //Ĭ��ֵ
    TFT_SEND_CMD(0xe7);             //VREG2_CTL
    TFT_SEND_DATA(0x56);            //-3V
    TFT_SEND_DATA(0x43);	        //

    TFT_SEND_CMD(0xF0);             //SET_GAMMA1
    TFT_SEND_DATA(0x1f);
    TFT_SEND_DATA(0x41);
    TFT_SEND_DATA(0x1B);
    TFT_SEND_DATA(0x55);
    TFT_SEND_DATA(0x36);
    TFT_SEND_DATA(0x3d);
    TFT_SEND_DATA(0x3e);
    TFT_SEND_DATA(0x0); 
    TFT_SEND_DATA(0x16);
    TFT_SEND_DATA(0x08);
    TFT_SEND_DATA(0x09);
    TFT_SEND_DATA(0x15);
    TFT_SEND_DATA(0x14);
    TFT_SEND_DATA(0xf); 

    TFT_SEND_CMD(0xF1);             //SET_GAMMA2
        
    TFT_SEND_DATA(0x1f);
    TFT_SEND_DATA(0x41);
    TFT_SEND_DATA(0x1B);
    TFT_SEND_DATA(0x55);
    TFT_SEND_DATA(0x36);
    TFT_SEND_DATA(0x3d);
    TFT_SEND_DATA(0x3e);
    TFT_SEND_DATA(0x0); 
    TFT_SEND_DATA(0x16);
    TFT_SEND_DATA(0x08);
    TFT_SEND_DATA(0x09);
    TFT_SEND_DATA(0x15);
    TFT_SEND_DATA(0x14);
    TFT_SEND_DATA(0xf); 

    TFT_SEND_CMD(0xfe);         //�ر�Inter register enable
    TFT_SEND_CMD(0xff);

    TFT_SEND_CMD(0x35);         //Tearing Effect Line ON
    TFT_SEND_DATA(0x00);
    TFT_SEND_CMD(0x44);         //Scan line set
    TFT_SEND_DATA(0x00);
    TFT_SEND_CMD(0x11);         //Sleep Out
    delay_ms (120);          //DELAY120ms
    TFT_SEND_CMD(0x29);         //��ʾ��

    TFT_SEND_CMD(0x2A); //Set Column Address 
    TFT_SEND_DATA(0x00);
    TFT_SEND_DATA(0x00); 
    TFT_SEND_DATA(0x00); 
    TFT_SEND_DATA(0x9f); 
    
    TFT_SEND_CMD(0x2B); //Set Page Address 
    TFT_SEND_DATA(0x00); 
    TFT_SEND_DATA(0x18); 
    TFT_SEND_DATA(0x00); 
    TFT_SEND_DATA(0x67); 
    TFT_SEND_CMD(0x2c); 
  }
void display_char16_16(unsigned int x,unsigned int y,unsigned long color,const unsigned char *point)
{
   unsigned int column;
  unsigned char tm=0,temp;
   TFT_SEND_CMD(0x2a);    //Column address set
  TFT_SEND_DATA(0X00);    //start column
  TFT_SEND_DATA(x+TFT_COLUMN_OFFSET);
  x=x+15;
  TFT_SEND_DATA(0X00);    //end column
  TFT_SEND_DATA(x+TFT_COLUMN_OFFSET);

  TFT_SEND_CMD(0x2b);     //Row address set
  TFT_SEND_DATA(0X00);    //start row
  TFT_SEND_DATA(y+TFT_LINE_OFFSET); 
  y=y+15;
  TFT_SEND_DATA(0X00);    //end row
  TFT_SEND_DATA(y+TFT_LINE_OFFSET);
    TFT_SEND_CMD(0x2C);     //Memory write
    
    
  for(column=0;column<32;column++)  //column loop
          {
        temp=*point;
        for(tm=0;tm<8;tm++)
        {
        if(temp&0x01)
          {
 
          TFT_SEND_DATA(color>>8);
          TFT_SEND_DATA(color);
          }
        else 
          {
     
          TFT_SEND_DATA(0);
          TFT_SEND_DATA(0);
          }
          temp>>=1;
        }
        point++;
          
      }
}
void Picture_display(const unsigned char *ptr_pic)
  {
    unsigned int ROW,column;
	TFT_SEND_CMD(0x2a);     //Column address set
  TFT_SEND_DATA(0x00);    //start column
  TFT_SEND_DATA(0x00+TFT_COLUMN_OFFSET); 
  TFT_SEND_DATA(0x00);    //end column
  TFT_SEND_DATA(PIC_LEN-1+ TFT_COLUMN_OFFSET);

  TFT_SEND_CMD(0x2b);     //Row address set
  TFT_SEND_DATA(0x00);    //start row
  TFT_SEND_DATA(0x00+TFT_LINE_OFFSET); 
  TFT_SEND_DATA(0x00);    //end row
  TFT_SEND_DATA(PIC_HIG-1+ TFT_LINE_OFFSET);
    TFT_SEND_CMD(0x2C);     //Memory write
    for(ROW=0;ROW<PIC_HIG;ROW++)        //ROW loop
      {   
		
	for(column=0;column<PIC_LEN;column++)	//column loop
          {
            TFT_SEND_DATA(*ptr_pic++);
			TFT_SEND_DATA(*ptr_pic++);
          }
      }
  }

void IO_init(void)
{
  PC_DDR|=0xFF;                         //PC  06,07��03,04,07���ģʽ
  PC_CR1|=0xFF;
  PC_CR2|=0xFF;
  PC_ODR=0XFF;
  PD_DDR|=0xF7;                         //PD  02���ģʽ 03 ��������ģʽ
  PD_CR1|=0xF7;                        /*������������*/
  PD_CR2|=0xF7;                         /*�������ж�*/
  PD_ODR=0XFF;

}

int main()
{ 

  IO_init();
  TFT_init();
	
  while(1)
  {
    TFT_full(RED);
	delay_ms(1000);
	TFT_full(GREEN);
	delay_ms(1000);
	TFT_full(BLUE);
	delay_ms(1000);
	TFT_clear();
		delay_ms(1000);
	display_char16_16(48,0,RED,china_char[0]);
		display_char16_16(112,0,GREEN,china_char[1]);
		display_char16_16(0,30,BLUE,china_char[2]);
		display_char16_16(32,30,0XFFFF,china_char[3]);
		display_char16_16(64,30,BLUE,china_char[4]);
		display_char16_16(96,30,GREEN,china_char[5]);
		display_char16_16(143,30,RED,china_char[6]);
		display_char16_16(72,46,BLUE,china_char[7]);
		display_char16_16(88,46,GREEN,china_char[8]);
		display_char16_16(72,64,RED,china_char[9]);
		display_char16_16(88,64,BLUE,china_char[10]);
		delay_ms(3000);
		TFT_clear();
             
  }
}

